﻿//var num = document.getElementById("").value;

var total = new Array();
var operand1 = new Array();
var operand2 = new Array();

function num(val) {
    operand1.push(val);
    var concat = operand1.join("");
 
    document.getElementById("display").innerHTML = concat;
}